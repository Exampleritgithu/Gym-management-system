const http = require('node:http');
const hostname = '127.0.0.1';
const port = 3000;
const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/html');
  res.end(`!DOCTYPE html>
  <html lang="en">
  
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Gym fitness</title>
  
  </head>
  
  
  <link rel="stylesheet" href="SEMESTER PROJECT/GYM .css">
  <style>
      /*css reset*/
      body {
          margin: 0px;
          padding: 0px;
          background: url('1.jpg');
  
      }
  
      .left {
  
          color: red;
          position: absolute;
          left: 28px;
          top: 1px;
  
      }
  
      .left img {
          width: 100px;
          filter: invert(100%);
      }
  
      .left div {
          text-align: center;
          height: -2px;
          line-height: 0%;
          font-size: 20px;
          padding: -1px;
      }
  
      .center {
  
          padding: 0%;
          color: red;
          display: block;
          width: 33%;
          margin: 20px auto;
  
      }
  
      .right {
  
          color: red;
          display: inline-block;
          position: absolute;
          right: 20px;
          top: 20px;
  
      }
  
      .navbar {
          display: inline-block;
          width: 100%;
          padding: 0%;
  
      }
  
      .navbar li {
          color: white;
          display: inline-block;
          font-size: 20px;
      }
  
      .navbar li a {
          color: white;
          text-decoration: none;
          padding: 10px 10px;
      }
  
      .navbar li a:hover,
      .navbar li a.active {
          text-decoration: underline;
          color: gray;
      }
  
      .logon {
          color: white;
          font-family: lobster;
      }
  
      .btn {
          font-family: sans-serif;
          margin: 0px 9px;
          color: white;
          background-color: black;
          padding: 4px 14px;
          border: 2px solid gray;
          border-radius: 10px;
          font-size: 20px;
          cursor: pointer;
  
      }
  
      .btn:hover {
          background-color: rgb(38, 240, 78);
      }
  
      .container {
          color: white;
  
          margin: 15px 820px;
          padding: 17px;
          width: 33%;
          border-radius: 28px;
          position: absolute;
          text-align: center;
          font-style:oblique;
      }
  
      .formgroup input {
          text-align: center;
          background-color: beige;
          display: block;
          width: 231px;
          padding: 3px;
          margin: 11px auto;
          border: 2px solid black;
          border-radius: 6px;
          font-size: 14px;
  
      }
  
      .container h2 {
          font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
      }
  
      .btn1 {
          width: 80px;
          border-radius: 7px;
          padding: 6px;
  
      }
  
      .btn1:hover {
          background-color: greenyellow;
  
      }
  </style>
  
  <body>
      <header class="header">
          <!--  for logo-->
          <div class="left">
              <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
              <img src="logo1.png">
              <div class="logon">Alpha Fitness</div>
  
  
          </div>
          <!--  for button-->
          <div class="right">
              <button class="btn"><a href="register.html">Sign up</a></button>
              <button class="btn"><a href="login.html" target="_self">Log in</a> </button>
  
          </div>
          <!--  for navbar-->
          <div class="center">
  
              <ul class="navbar">
                  <li><a href='/' class="active">Home</a></li>
                  <li><a href='/aboutus.html'>About us</a> </li>
                  <li><a href='/fitness'>Fitness</a> </li>
                  <li><a href='/contactus.html'> contact</a></li>
              </ul>
          </div>
      </header>
      <div class="container">
          <h2>Join the best gym of islamabad <br>for membership</h2>
          <form action="noaction.php">
              <div class="formgroup">
                  <input type="text" name="" placeholder=" Enter you name">
              </div>
              <div class="formgroup">
                  <input type="text" name="" placeholder=" Enter you age">
              </div>
              <div class="formgroup">
                  <input type="text" name="" placeholder=" Enter you gender">
              </div>
              <div class="formgroup">
                  <input type="text" name="" placeholder=" Enter you Number">
              </div>
              <button class="btn1">submit</button>
          </form>
      </div>
      
  </body>
  
  </html>`);
});
server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});